#include "yolo_rvv.h"
#include "yolo_ref.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
using namespace yoloop;
void compare(const std::vector<Detection>& a,const std::vector<Detection>& b) {
 if(a.size()!=b.size()) std::abort();
 for(size_t i=0;i<a.size();++i) {
  if(a[i].label!=b[i].label || std::fabs(a[i].score-b[i].score)>1e-3f ||
     std::fabs(a[i].x1-b[i].x1)>1e-2f || std::fabs(a[i].y1-b[i].y1)>1e-2f ||
     std::fabs(a[i].x2-b[i].x2)>1e-2f || std::fabs(a[i].y2-b[i].y2)>1e-2f) std::abort();
 }
}
int main() {
 for(int n:{0,1,7,8,9,17,4095,4096,4097}) {
  AnchorTable t;t.n=n;
  for(int i=0;i<n;i++){t.gx.push_back(i%80+.5f);t.gy.push_back(i/80+.5f);t.stride.push_back(8);t.aw.push_back(16);t.ah.push_back(24);}
  const int nc=3,reg=16;
  for(float conf:{.25f,.5f}) {
   std::vector<float> pred((4*reg+nc)*std::max(n,1));
   for(size_t j=0;j<pred.size();j++)pred[j]=std::sin(float(j)*.7f)*3;
   compare(riscv::decode(pred.data(),t,nc,conf),ref::decode(pred.data(),t,nc,conf));
   compare(riscv::decode_af_raw(pred.data(),t,nc,reg,conf),ref::decode_af_raw(pred.data(),t,nc,reg,conf));
   compare(riscv::decode_af_dist(pred.data(),t,nc,conf),ref::decode_af_dist(pred.data(),t,nc,conf));
  }
 }
 std::puts("PASS: v5/raw/dist counts, labels, values and anchor order; 9 lengths x 2 thresholds");
}
